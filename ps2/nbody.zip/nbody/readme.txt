/*******************************************************************************
 *  Name:    
 *  NetID:   
 *  Precept: 
 ******************************************************************************/

Programming Assignment 2: N-Body Simulation

Operating system (such as OS X or Windows):    
Machine (such as Dell Latitude, MacBook Pro):  
Text editor (such as DrJava):                  
Hours to complete assignment (optional):       



/**********************************************************************
 *  Did you receive help from classmates, past COS 126 students, or
 *  anyone else?  Please list their names.  ("A Sunday lab TA" or 
 *  "Office hours on Thursday" is ok if you don't know their name.)
 **********************************************************************/



/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/



/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/


